//
//  ViewController.swift
//  apPizza
//
//  Created by John Veronelli on 6/30/16.
//  Copyright © 2016 John Veronelli. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var ingredientsField: UILabel!
    var pizza = Pizza(tamano: "", masa: "",queso: "",ingredientes: "")
    @IBOutlet weak var ingredientsLabel: UILabel!    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewDidAppear(animated: Bool) {
        print("check")
        ingredientsField.text = String(pizza.masa!) + (" ,") + String(pizza.queso!) + (" ,") + String(pizza.tamano!)
        
        ingredientsLabel.text = String(pizza.ingredientes!)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        // Dispose of any resources that can be recreated.
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if (segue.identifier == "tamaño") {
            print("tamaño")
            let destinationViewController = segue.destinationViewController as! Taman_oViewController
            destinationViewController.pizza = self.pizza
        }
        if (segue.identifier == "masa") {
            print("masa")
            let destinationViewController = segue.destinationViewController as! masaViewController
            destinationViewController.pizza = self.pizza
        }
        if (segue.identifier == "queso") {
            print("queso")
            let destinationViewController = segue.destinationViewController as! quesoViewController
            destinationViewController.pizza = self.pizza
        }
        if (segue.identifier == "ingredientes") {
            print("ingredientes")
            let destinationViewController = segue.destinationViewController as! ingredientesViewController
            destinationViewController.pizza = self.pizza
        }
        if (segue.identifier == "confirmar") {
            print("confirmacion")
            let destinationViewController = segue.destinationViewController as! confirmarViewController
            destinationViewController.pizza = self.pizza
        }
        
    }


}

