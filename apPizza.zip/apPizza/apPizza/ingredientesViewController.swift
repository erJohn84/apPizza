//
//  ingredientesViewController.swift
//  apPizza
//
//  Created by John Veronelli on 7/1/16.
//  Copyright © 2016 John Veronelli. All rights reserved.
//

import UIKit

class ingredientesViewController: UIViewController {

    @IBOutlet weak var jamonButton: UIButton!
    @IBOutlet weak var peppButton: UIButton!
    @IBOutlet weak var cebollaButton: UIButton!
    @IBOutlet weak var piñaButton: UIButton!
    @IBOutlet weak var pimentonButton: UIButton!
    @IBOutlet weak var aceitunaButton: UIButton!
    @IBOutlet weak var anchoaButton: UIButton!
    @IBOutlet weak var listaIngred: UILabel!
    
    var pizza = Pizza?()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillDisappear(animated: Bool) {        
        pizza?.queso = listaIngred.text
        let viewController = ViewController()
        viewController.pizza.ingredientes = pizza?.ingredientes
    }
    
    @IBAction func jamon (sender: UIButton){
        listaIngred.text = listaIngred.text! + "jamon, "
    }
    
    @IBAction func pepp (sender: UIButton){
        listaIngred.text = listaIngred.text! + "pepperoni, "
    }
    
    @IBAction func cebolla (sender: UIButton){
        listaIngred.text = listaIngred.text! + "cebolla, "
    }
    
    @IBAction func piña (sender: UIButton){
        listaIngred.text = listaIngred.text! + "piña, "
    }
    
    @IBAction func pimenton (sender: UIButton){
        listaIngred.text = listaIngred.text! + "pimenton, "
    }
    
    @IBAction func aceituna (sender: UIButton){
        listaIngred.text = listaIngred.text! + "aceituna, "
    }
    
    @IBAction func anchoa (sender: UIButton){
        listaIngred.text = listaIngred.text! + "anchoa, "
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
