//
//  masaViewController.swift
//  apPizza
//
//  Created by John Veronelli on 7/1/16.
//  Copyright © 2016 John Veronelli. All rights reserved.
//

import UIKit

class masaViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    @IBOutlet weak var masaPicker: UIPickerView!
    var pizza = Pizza?()
    @IBOutlet weak var seleccion: UILabel!
    let pickerData = ["Delgada","Crujiente","Gruesa"]
    var value = "Delgada"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        masaPicker.dataSource = self
        masaPicker.delegate = self
        
        
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(animated: Bool) {
        //let viewController = ViewController()
        
    }
    
    override func viewWillDisappear(animated: Bool) {
        let viewController = ViewController()
        viewController.pizza.masa = pizza?.masa
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        value = pickerData[row]
        seleccion.text = pickerData[row]
        pizza?.masa = value
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
