//
//  quesoViewController.swift
//  apPizza
//
//  Created by John Veronelli on 7/1/16.
//  Copyright © 2016 John Veronelli. All rights reserved.
//

import UIKit

class quesoViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    @IBOutlet weak var quesoPicker: UIPickerView!
    var pizza = Pizza?()
    @IBOutlet weak var seleccion: UILabel!
    let pickerData = ["mozarela","cheddar","parmesano", "sin queso"]
    var value = "sin queso"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        quesoPicker.dataSource = self
        quesoPicker.delegate = self
        
        
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(animated: Bool) {
        //let viewController = ViewController()
        
    }
    
    override func viewWillDisappear(animated: Bool) {
        let viewController = ViewController()
        viewController.pizza.queso = pizza?.queso
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        value = pickerData[row]
        seleccion.text = pickerData[row]
        pizza?.queso = value
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
