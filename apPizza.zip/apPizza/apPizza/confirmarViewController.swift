//
//  confirmarViewController.swift
//  apPizza
//
//  Created by John Veronelli on 7/2/16.
//  Copyright © 2016 John Veronelli. All rights reserved.
//

import UIKit

class confirmarViewController: UIViewController {
    
    @IBOutlet weak var listado: UILabel!
    var pizza = Pizza?()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        listado.text = String(pizza!.masa!) + (" ,") + String(pizza!.tamano!) + (" ,") + String(pizza!.queso!) + (" ,") + String(pizza!.ingredientes!)

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
